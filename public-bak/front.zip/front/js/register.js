/**
 * Created by HUCC on 2017/11/14.
 */
$(function () {

  //1. 获取验证码
  $(".btn_getcode").on("click", function (e) {
    e.preventDefault();

    var $this = $(this);
    //只要一点击，我们需要先禁用按纽
    $(this).addClass("disabled").prop("disabled", true).text("正在发送中....");


    //发送ajax请求
    $.ajax({
      type: "get",
      url: "/user/vCode",
      success: function (data) {
        //我们获取到验证码，直接打印，相当于手机获取到了验证
        console.log(data.vCode);

        //开启倒计时，让用户60秒后可以再次点击
        var count = 5;
        var timer = setInterval(function () {
          count--;
          $this.text(count + "秒后再次发送");

          //如果count小于等于0了，恢复
          if (count <= 0) {
            $this.removeClass("disabled").prop("disabled", false).text("获取验证码");
            //清除定时器
            clearInterval(timer);
          }
        }, 1000);

      }
    });

  });


  //2. 注册


});